import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Header from './components/layout/Header';
import Home from './components/pages/Home';

import CodeGen from './components/Event/CodeGen'

class App extends Component {
  render() {
    return (
      <Router>
        <div>
          <Header />
          <div className="container">
            <Switch>
              <Route exact path="/" component={Home} />
              <Route exact path="/codeGen" component={CodeGen} />
            </Switch>
          </div>
        </div>
      </Router>
    );
  }
}

export default App;
