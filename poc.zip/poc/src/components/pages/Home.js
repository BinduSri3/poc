import React, { Component } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Route, NavLink } from 'react-router-dom'
import ReactDOM from 'react-dom';


class Home extends Component {
    constructor(props) {
        super(props)
        this.state = {
            title: '',
            host: '',
            description: '',
            basepath: '',
            artifactType: '',
            file: '',
            yamlpath: ''
        }
    }
    onSubmit = (e) => {
        this.props.history.push('/codeGen')
    }

    changeHandler = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    handlePath = (e) => {
        e.preventDefault()
        console.log(this.state)
        axios
            .post("http://localhost:8200", this.state, {
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,PATCH,OPTIONS"
                }
            })
            .then(response => {
                console.log(response.data)
                alert(response.data)
                window.location.replace(response.data)
                // else{
                //     alert('Submition Failed');
                // }
            })
            .catch(error => {
                console.log(error)
                alert('Submition Failed');
            }
            ).then(data => this.setState({ yamlpath: data })
            );


    }


    submitHandler = e => {
        e.preventDefault()
        console.log(this.state)
        axios
            .post("http://localhost:8200", this.state, {
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,PATCH,OPTIONS"
                }
            })
            .then(response => {
                console.log(response)
                if (response.data != null) {
                    alert('Submitted Successfully');
                }
                // else{
                //     alert('Submition Failed');
                // }
            })
            .catch(error => {
                console.log(error)
                alert('Submition Failed');
            }
            ).then(data => this.setState({ yamlpath: data })
            );
    }

    render() {
        const { title, host, description, basepath, artifactType, file, yamlpath } = this.state

        return (

            <div id="s1">
                {/* 
                 <img src={
                 } alt="OSCEImage" id="logo" />
                <img src={api} alt="ApiBuilder" id="img" />  */}
                <div id="first">
                    <form onSubmit={this.submitHandler} >

                        <table align="center">
                            <h1>Data Driven API Builder</h1>
                            <tr><td>Title:</td><td> <input type="text" name="title" value={title} onChange={this.changeHandler} pattern="[a-zA-Z0-9 ]{1,20}" required /></td></tr>
                            {/* <tr><td>Version:</td><td> <input type="text" name="version" value={version} onChange={this.changeHandler} required pattern="[a-zA-Z0-9-.]{1,15}"   /></td></tr> */}
                            <tr><td>Host:</td><td> <input type="text" name="host" value={host} onChange={this.changeHandler} pattern="[a-zA-Z_0-9@\!#\$\^%*()+=\-[]\\\';,\.\/\{\}\|\:<>\?: ]{1,}" required /></td></tr>
                            <tr><td>Description:</td><td> <input type="text" name="description" value={description} onChange={this.changeHandler} pattern="[a-zA-Z0-9 ]{1,20}" required /></td></tr>
                            <tr><td>BasePath:</td><td> <input type="text" name="basepath" value={basepath} onChange={this.changeHandler} required pattern="[a-zA-Z0-9/]{1,20}" /></td></tr>
                            <tr><td>Artifact Type:</td>
                                <td><select id="dropdown"><option value="SELECT">--SELECT--</option>
                                    <option value="json">JSON</option>
                                    <option value="yaml">YAML</option>
                                </select></td>
                            </tr>
                            <tr><td>Browse Schema:</td><td> <input type="file" name="file" value={file} onChange={this.changeHandler} required /></td></tr>
                            {/* <tr><td>YamlPath:</td><td> <input type="text" name="yamlpath" value={yamlpath} onChange={this.changeHandler} /></td></tr> */}
                        </table>

                        <center>
                            <div>
                                <button type="submit" class="form-submit-button" required="true" >Generate API artifacts</button>
                                {'                                                                                              '}
                                <button type="submit" class="form-submit-button" onClick={this.onSubmit}>Next</button>
                            </div>


                        </center>
                    </form >
                </div >

                {/* <p>Download the API Document from above link <a href="C:\Users\bkongara\Desktop\YamlFile.yml" onClick={this.handlePath} >path</a></p>
                <DownloadLink filename="C:/Users/bkongara/Desktop/YamlFile.yml" exportFile={() => ""}>Save to disk</DownloadLink> */}
            </div >
        )
    }
}
// const routing = (
//     <Router>
//         <div>
//             <ul>
//                 <li>
//                     <NavLink to="/pathpage" exact activeStyle={
//                         { color: 'green' }
//                     }>pathpage</NavLink>
//                 </li>
//             </ul>
//             <Route path="/pathpage" component={pathpage} />
//         </div>
//     </Router>
// )
ReactDOM.render(Home, document.getElementById('root'));
export default Home;