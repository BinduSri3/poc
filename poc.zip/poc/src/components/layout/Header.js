import React from 'react';
import { Link } from 'react-router-dom';
import logo from "../images/OSCE1.png";

const Header = () => {
    return (
        <nav className="navbar navbar-inverse">
            <div className="container-fluid">
                <div className="navbar-header navbar-left " >
                    <div >
                        {'                         '}
                        <img src={logo} height='80px' width='80px' alt="osce2 logo" className="logo" color="white"></img></div>
                </div>
                <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1" id="div-image">
                    {/* <span class="glyphicon glyphicon-align-justify"></span> */}

                    <ul className="nav navbar-nav navbar-right" >
                        <li className="home"><Link to="/About" className="glyphicon glyphicon-user"> About</Link></li>
                        <li className="home"><Link to="/Contact" className="glyphicon glyphicon-cloud"> Contact us</Link></li>
                    </ul>
                    <ul className="nav navbar-nav navbar-right" >
                        <li className="home"><Link to="/" className="glyphicon glyphicon-home"> Home</Link><span className="sr-only">(current)</span></li>
                        <li className="home"><Link to="/codeGen" className="	glyphicon glyphicon-plus-sign"> CodeGen </Link></li>
                    </ul>
                </div>
            </div>
        </nav>)
}
export default Header;