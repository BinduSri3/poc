import React, { Component } from 'react';
import { Link } from "react-router-dom";
import Home from '../pages/Home';
import createHistory from 'history/createBrowserHistory';
import axios from 'axios';
import Select from "react-dropdown-select";

const history = createHistory();
class CodeGen extends Component {

    handleChange(event) {
        this.setState({ value: event.target.value });
    }

    handleSubmit(event) {
        alert('Your favorite flavor is: ' + this.state.value);
        event.preventDefault();
    }

    render() {
        return (
            <div>
                <div>
                    <h1>CodeGen</h1>
                </div>
                <div class="col-sm-6"> <label>
                    <select >
                        <option value="Server">Client</option>
                        <option value="lime">Lime</option>
                        <option value="coconut">Coconut</option>
                        <option value="mango">Mango</option>
                    </select>
                </label>

                </div>
                {'                                                                                          '}
                <div class="col-sm-6"> <label>
                    <select >
                        <option value="Server">Server</option>
                        <option value="lime">Lime</option>
                        <option value="coconut">Coconut</option>
                        <option value="mango">Mango</option>
                    </select>
                </label>
                </div>
                <div className="col-md-2 offset-md-4"><Link to="/"><button class="btn btn-warning btn-sm"><span class="glyphicon glyphicon-arrow-left"></span>Back</button>
                </Link>
                </div>
                {/* <div class="btn-group">
                    <button class="btn btn-primary">CODEGEN</button>
                    <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu"></ul>
                </div> */}
            </div >
        );
    }
}
export default CodeGen;